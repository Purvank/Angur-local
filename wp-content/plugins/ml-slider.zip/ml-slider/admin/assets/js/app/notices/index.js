import CSSManagerNotice from './CSSManagerNotice.vue'

export { CSSManagerNotice }
