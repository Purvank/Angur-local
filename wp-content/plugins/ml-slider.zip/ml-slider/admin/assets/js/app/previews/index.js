import Preview from './Preview.vue'

export { Preview }
